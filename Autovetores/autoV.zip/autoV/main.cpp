
#include "headers/matriz.hpp"
#include "headers/opeMatriz.hpp"
#include "headers/autov.hpp"

using namespace std;

double determinante(matriz A){
	double multiplicacao = 0;
	double soma = 0;

  	double y = 0;
  	int x = 0;
  	int n = 0;

	for (n=0; n<A.getNumLinha(); n++) {// numero de loops

	    for (x=0; x<A.getNumLinha(); x++) {

	        y = (x + n) % (int) A.getNumLinha();
	        multiplicacao = multiplicacao * A.get(x,(int) y);

	    }
    		soma = soma + multiplicacao;
  	}

  	return soma;

}

matriz gerarAutovetor(matriz A, double a){
	matriz * I = new matriz(A.getNumLinha());

	matriz nulo = opeMatriz::gerarVetorColunaZeros(A.getNumLinha());

/*
	nulo.push(1, 0,0);
	nulo.push(1, 1,0);
	nulo.push(1, 2,0);
*/
	matriz T = opeMatriz::menos( (A), opeMatriz::multiplyByEscalar(*I, a) );

	cout << "transformação T = \n";
	T.escreveMatriz();

	return opeMatriz::resolverSLComLU(opeMatriz::makeLU(T), nulo );
}

void testarAutovetor(matriz A, matriz autovetor, double a){

	matriz At = opeMatriz::multiply(A, autovetor);
	matriz lt = opeMatriz::multiplyByEscalar(autovetor, a);

	cout << " desejamos que At = \n";
	At.escreveMatriz();

	cout << "seja igual a lt = \n";

	lt.escreveMatriz();

}

int main(){
	//system("clear");

	/*
		relação de funções
			gerarVetorColunaZeros **
			multiply **
			transpor **
			multiplyByEscalar **
			produtoEscalar **
			Modulo **
			normalizar **
			mais **
			menos **
			makeLU **
			resolverSistemaTriangularSup **
			resolverSistemaTriangularInf **
	*/
	matriz * A = new matriz(3);
	A->push(4, 0,0);
	A->push(1, 1,0);
	A->push(2, 2,0);
	/*

	A->push(5, 0,1);
	A->push(2, 2,0);
	A->push(1, 1,2);
	A->push(1, 2,2);
	*/
	A->push(5, 1,1);
	A->push(5, 2,2);

	A->escreveMatriz();

	//cout << " determinante de A = " << determinante(*A) << endl;

	matriz b = opeMatriz:: gerarVetorColunaZeros(3);

	b.push(1, 0,0);
	b.push(1, 1,0);
	b.push(2, 2,0);

	b.escreveMatriz();

	double a = autov::metodoPotenciaInversa(*A, b, 0.00001);

	cout << "maior autovalor = " << a << endl;

	matriz autov = gerarAutovetor(*A, a);

	testarAutovetor(*A, autov, a);

/*
	matriz R = opeMatriz::resolverSLComLU(opeMatriz:: makeLU(*A), b);

	R.escreveMatriz();
*/

	return 0;
}