/*
	AUTOR: RUBENS ANDERSON - COMPUTAÇÃO UFC 2017
	DESC: classe com operações de autovalores
*/
#include "../headers/autov.hpp"

double autov::metodoPotencia(matriz A, matriz x, double epsilon){ // retorna o autovalor l1
	    // fluxo excessão start
	if(true)
	{
		if(A.getNumLinha() <= 0 || A.getNumColuna() <= 0){
			cout << "	Nao vale! nao passe matriz vazia!\n (metodoPotencia)\n";
			return 0;
		}
		if(x.getNumLinha() <= 0 || x.getNumColuna() <= 0){
			cout << "	Nao vale! nao passe vetor chute vazio!\n (metodoPotencia)\n";
			return 0;
		}
		if(A.getNumColuna() != x.getNumLinha()){
			cout << "	Nao, cara! Matrizes incoerentes!\n (metodoPotencia)\n";
			return 0;
		}
		if(epsilon <= 0){
			cout << "	Nao pode! precisao deve se positiva!\n (metodoPotencia)\n";
			return 0;
		}
	}
	    // fluxo excessão finish
	matriz y = x;
	matriz u;
	double oldLambida = 10;
	double newLambida = 0;
/*
	matriz y = opeMatriz::multiply(A, u);

	matriz holder = opeMatriz::multiply(opeMatriz::transpor(u), y);

	double oldLambida = holder.get(0,0);

	// dados:
	cout << "u(0) = \n";
	u.escreveMatriz();
	cout << "uy0) = \n";
	y.escreveMatriz();

	cout << oldLambida << " = oldLambida\n 	entrando no loop...\n\n";
*/
	int i = 0;

	matriz holder;
	while(fabs(oldLambida - newLambida) / fabs(oldLambida) > epsilon){

		i++;

		oldLambida = newLambida;

		u = opeMatriz::normalizar(y);
		y = opeMatriz::multiply(A, u);

		holder = opeMatriz::multiply(opeMatriz::transpor(u), y);

		newLambida = holder.get(0,0);
	}
	return newLambida;
}


double autov::metodoPotenciaInversa(matriz A, matriz x, double epsilon){ // retorna o autovalor l1
	    // fluxo excessão start
	if(true)
	{
		if(A.getNumLinha() <= 0 || A.getNumColuna() <= 0){
			cout << "	Nao vale! nao passe matriz vazia!\n (metodoPotenciaInversa)\n";
			return 0;
		}
		if(x.getNumLinha() <= 0 || x.getNumColuna() <= 0){
			cout << "	Nao vale! nao passe vetor chute vazio!\n (metodoPotenciaInversa)\n";
			return 0;
		}
		if(A.getNumColuna() != x.getNumLinha()){
			cout << "	Nao, cara! Matrizes incoerentes!\n (metodoPotenciaInversa)\n";
			return 0;
		}
		if(epsilon <= 0){
			cout << "	Nao pode! precisao deve se positiva!\n (metodoPotenciaInversa)\n";
			return 0;
		}
	}

	A.escreveMatriz();
	x.escreveMatriz();

	matriz u = opeMatriz::normalizar(x);

	vector <matriz> LU = opeMatriz::makeLU(A);

	matriz L = LU[0];
	matriz U = LU[1];

	matriz w = opeMatriz::resolverSistemaTriangularInf(L, u);
	matriz y = opeMatriz::resolverSistemaTriangularSup(U, w);

	matriz holder = opeMatriz::multiply( opeMatriz::transpor(u), y);

	double oldLambida = holder.get(0,0);
	double newLambida = 0;


	while(fabs(oldLambida - newLambida) / fabs(oldLambida) > epsilon){

		oldLambida = newLambida;
		newLambida = 0;

		u = opeMatriz::normalizar(y);

		w = opeMatriz::resolverSistemaTriangularInf(L, u);
		y = opeMatriz::resolverSistemaTriangularSup(U, w);

		holder = opeMatriz::multiply( opeMatriz::transpor(u), y);

		newLambida = holder.get(0,0);

	}
	return 1 / newLambida;
}