/*
	AUTOR: RUBENS ANDERSON - COMPUTAÇÃO UFC 2017
	DESC: Operações sobre matrizes definidas na classe matriz
*/
#ifndef AUTOV_H
#define AUTOV_H

#include <iostream>
#include <vector>
#include <math.h>
//#include "matriz.hpp"
#include "opeMatriz.hpp"

using namespace std;

class autov{
public:

	autov();
	virtual ~autov();

	static double metodoPotencia(matriz A, matriz x, double epsilon);

	static double metodoPotenciaInversa(matriz A, matriz x, double epsilon);

};

#endif